# One-Lovely-Engine
A recreation of the OLC Engine (By Javidx9 on YT) made in Lua with the LOVE2D engine
Initially Made for the OLC Viewer Submission (And as a programming challenge)

Download the OneLovelyCoder.lua file in order to use it as a module in LOVE2D
